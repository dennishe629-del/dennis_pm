﻿// ── State ──
const S = {
  canvas: null, zoom: 1,
  history: [], historyIndex: -1,
  font: 'serif', textColor: '#ffffff',
  textBold: false, textItalic: false, fontSize: 36,
  qty: 1, color: '#1a1a2e', colorName: 'Navy', size: 'M',
  uploadedImgs: [], hasDesign: false
};

// ── Canvas Init ──
window.addEventListener('DOMContentLoaded', () => {
  S.canvas = new fabric.Canvas('mainCanvas', {
    width: 420, height: 500,
    backgroundColor: '#e8e4de',
    selection: true,
    preserveObjectStacking: true
  });
  drawShirt(S.color);
  // Print zone border
  const zone = new fabric.Rect({
    left: 80, top: 110, width: 260, height: 230,
    fill: 'transparent',
    stroke: '#6c63ff', strokeWidth: 1.5,
    strokeDashArray: [6, 4],
    selectable: false, evented: false, name: '__printzone__'
  });
  S.canvas.add(zone);
  S.canvas.renderAll();
  S.canvas.on('object:modified', saveHistory);
  S.canvas.on('object:added', () => { updateLayers(); S.hasDesign = true; updateFooter(); });
  S.canvas.on('object:removed', () => { updateLayers(); updateFooter(); });
  S.canvas.on('selection:created', updateFooter);
  S.canvas.on('selection:cleared', updateFooter);
  saveHistory();
});

function drawShirt(color) {
  S.canvas.getObjects().forEach(o => { if (o.name === '__shirt__') S.canvas.remove(o); });
  const shirt = new fabric.Path(
    'M 60 80 L 0 130 L 50 150 L 50 460 L 370 460 L 370 150 L 420 130 L 360 80 L 290 50 Q 210 90 130 50 Z',
    { fill: color, stroke: 'rgba(0,0,0,0.12)', strokeWidth: 1.5,
      selectable: false, evented: false, name: '__shirt__' }
  );
  S.canvas.insertAt(shirt, 0);
  S.canvas.renderAll();
}

// ── History ──
function saveHistory() {
  const json = S.canvas.toJSON(['name']);
  S.history = S.history.slice(0, S.historyIndex + 1);
  S.history.push(json); S.historyIndex++;
  if (S.history.length > 25) { S.history.shift(); S.historyIndex--; }
}
function undoAction() {
  if (S.historyIndex <= 0) { showToast('Nothing to undo'); return; }
  S.historyIndex--;
  S.canvas.loadFromJSON(S.history[S.historyIndex], () => { S.canvas.renderAll(); updateLayers(); });
}

// ── Modal ──
function openStudio() { document.getElementById('overlay').classList.add('on'); document.body.style.overflow='hidden'; }
function closeStudio() { document.getElementById('overlay').classList.remove('on'); document.body.style.overflow=''; }
function handleOverlay(e) { if (e.target===document.getElementById('overlay')) closeStudio(); }
document.addEventListener('keydown', e => { if (e.key==='Escape') closeStudio(); });

// ── Product Options ──
function setColor(el, hex, name) {
  document.querySelectorAll('.color-swatch').forEach(s=>s.classList.remove('active'));
  el.classList.add('active');
  document.getElementById('colorBadge').textContent = name;
  S.color=hex; S.colorName=name; drawShirt(hex);
}
function setColor2(el, hex, name) {
  document.querySelectorAll('.opt-color').forEach(s=>s.classList.remove('active'));
  el.classList.add('active');
  S.color=hex; S.colorName=name;
  document.getElementById('colorBadge').textContent = name;
  drawShirt(hex);
}
function setSz(el) {
  document.querySelectorAll('.sz').forEach(s=>s.classList.remove('active'));
  el.classList.add('active'); S.size=el.textContent;
}
function selSz2(el) {
  document.querySelectorAll('.opt-sz').forEach(s=>s.classList.remove('active'));
  el.classList.add('active'); S.size=el.textContent;
}
function changeQty(d) {
  S.qty = Math.max(1, Math.min(99, S.qty+d));
  document.getElementById('qtyVal').value = S.qty;
  document.getElementById('studioPrice').textContent = '$'+(34.99*S.qty).toFixed(2);
}

// ── Tab Switching ──
function switchTab(el, panel) {
  document.querySelectorAll('.stab').forEach(t=>t.classList.remove('on'));
  document.querySelectorAll('.spanel').forEach(p=>p.classList.remove('on'));
  el.classList.add('on');
  document.getElementById('panel-'+panel).classList.add('on');
}
// ── Upload ──
function triggerUpload() { document.getElementById('fileInput').click(); }
function handleFile(e) {
  const file = e.target.files[0];
  if (!file) return;
  if (file.size > 20*1024*1024) { showToast('File too large (max 20MB)', 'warn'); return; }
  const reader = new FileReader();
  reader.onload = ev => {
    fabric.Image.fromURL(ev.target.result, img => {
      const maxW=220, maxH=190;
      const scale = Math.min(maxW/img.width, maxH/img.height);
      img.set({ left:210, top:225, scaleX:scale, scaleY:scale,
                originX:'center', originY:'center', name:'image_'+Date.now() });
      S.canvas.add(img);
      S.canvas.setActiveObject(img);
      S.canvas.renderAll();
      saveHistory();
      addUploadThumb(ev.target.result, img);
      showToast('Image added!', 'success');
    });
  };
  reader.readAsDataURL(file);
  e.target.value = '';
}
function addUploadThumb(src, imgObj) {
  const grid = document.getElementById('uploadedGrid');
  const empty = grid.querySelector('[data-empty]');
  if (empty) empty.remove();
  const div = document.createElement('div');
  div.className = 'img-thumb';
  div.innerHTML = `<img src="${src}"><span class="rm" onclick="removeObjByName(event,'${imgObj.name}')">&#10005;</span>`;
  div.onclick = () => { S.canvas.setActiveObject(imgObj); S.canvas.renderAll(); };
  grid.appendChild(div);
}
function removeObjByName(e, name) {
  e.stopPropagation();
  const obj = S.canvas.getObjects().find(o=>o.name===name);
  if (obj) { S.canvas.remove(obj); S.canvas.renderAll(); saveHistory(); }
}

// ── Text ──
function selFont(el, font) {
  document.querySelectorAll('.fitem').forEach(f=>f.classList.remove('on'));
  el.classList.add('on'); S.font=font; updateActiveText();
}
function selColor(el, color) {
  document.querySelectorAll('.cpick').forEach(c=>c.classList.remove('on'));
  el.classList.add('on'); S.textColor=color; updateActiveText();
}
function toggleBold(el) {
  el.classList.toggle('on'); S.textBold=el.classList.contains('on'); updateActiveText();
}
function toggleItalic(el) {
  el.classList.toggle('on'); S.textItalic=el.classList.contains('on'); updateActiveText();
}
function updateFontSize(val) {
  S.fontSize=parseInt(val);
  document.getElementById('fontSizeLabel').textContent=val+'px';
  updateActiveText();
}
function updateActiveText() {
  const obj = S.canvas.getActiveObject();
  if (obj && obj.type==='textbox') {
    obj.set({ fontFamily:S.font, fill:S.textColor,
      fontWeight:S.textBold?'bold':'normal',
      fontStyle:S.textItalic?'italic':'normal',
      fontSize:S.fontSize });
    S.canvas.renderAll();
  }
}
function addText() {
  const txt = document.getElementById('textInput').value.trim();
  if (!txt) { showToast('Please enter some text first', 'warn'); return; }
  const t = new fabric.Textbox(txt, {
    left:210, top:225, originX:'center', originY:'center',
    width:200, fontFamily:S.font, fill:S.textColor,
    fontSize:S.fontSize,
    fontWeight:S.textBold?'bold':'normal',
    fontStyle:S.textItalic?'italic':'normal',
    textAlign:'center', name:'text_'+Date.now()
  });
  S.canvas.add(t);
  S.canvas.setActiveObject(t);
  S.canvas.renderAll();
  saveHistory();
  showToast('Text added!', 'success');
  document.getElementById('textInput').value = '';
}

// ── Layer Tools ──
function alignCenter() {
  const obj = S.canvas.getActiveObject();
  if (!obj||obj.name&&obj.name.startsWith('__')) { showToast('Select an element first'); return; }
  obj.set({ left:210, top:225, originX:'center', originY:'center' });
  S.canvas.renderAll(); saveHistory();
}
function bringForward() {
  const obj=S.canvas.getActiveObject();
  if (obj) { S.canvas.bringForward(obj); S.canvas.renderAll(); }
}
function sendBackward() {
  const obj=S.canvas.getActiveObject();
  if (obj) { S.canvas.sendBackwards(obj); S.canvas.renderAll(); }
}
function deleteSelected() {
  const obj=S.canvas.getActiveObject();
  if (!obj||obj.name&&obj.name.startsWith('__')) { showToast('Select an element first'); return; }
  S.canvas.remove(obj); S.canvas.renderAll(); saveHistory();
  showToast('Element deleted');
}
function clearCanvas() {
  const keep = S.canvas.getObjects().filter(o=>o.name&&o.name.startsWith('__'));
  S.canvas.clear();
  keep.forEach(o=>S.canvas.add(o));
  drawShirt(S.color);
  S.canvas.renderAll(); saveHistory();
  S.hasDesign=false; updateFooter();
  document.getElementById('uploadedGrid').innerHTML='<div data-empty style="grid-column:1/-1;font-size:11px;color:var(--muted);text-align:center;padding:12px">No images yet</div>';
  showToast('Canvas cleared');
}
function updateLayers() {
  const list=document.getElementById('layersList');
  const objs=S.canvas.getObjects().filter(o=>!o.name||!o.name.startsWith('__'));
  if (!objs.length) { list.innerHTML='<div style="font-size:11px;color:var(--muted);text-align:center;padding:20px">No layers yet</div>'; return; }
  list.innerHTML=objs.slice().reverse().map((o,i)=>{
    const icon=o.type==='textbox'?'🔤':'🖼';
    const label=o.type==='textbox'?(o.text.substring(0,16)+(o.text.length>16?'…':'')):'Image '+(objs.length-i);
    const idx=S.canvas.getObjects().indexOf(o);
    return `<div onclick="selectLayer(${idx})" style="display:flex;align-items:center;gap:8px;padding:8px 10px;background:var(--bg);border-radius:var(--rs);border:1px solid var(--border);font-size:12px;cursor:pointer">${icon} <span style="flex:1">${label}</span></div>`;
  }).join('');
}
function selectLayer(idx) {
  const obj=S.canvas.item(idx);
  if (obj) { S.canvas.setActiveObject(obj); S.canvas.renderAll(); }
}

// ── Zoom ──
function zoomCanvas(delta) {
  S.zoom=Math.max(0.5,Math.min(2,S.zoom+delta));
  S.canvas.setZoom(S.zoom);
  S.canvas.setDimensions({width:420*S.zoom,height:500*S.zoom});
  document.getElementById('zoomLabel').textContent=Math.round(S.zoom*100)+'%';
}

// ── Preview ──
function showPreview() {
  const prev=document.getElementById('previewCanvas');
  const ctx=prev.getContext('2d');
  ctx.fillStyle=S.color; ctx.fillRect(0,0,400,480);
  const dataURL=S.canvas.toDataURL({format:'png',multiplier:0.95});
  const img=new Image();
  img.onload=()=> { ctx.drawImage(img,0,0,400,480); document.getElementById('prevOverlay').classList.add('on'); };
  img.src=dataURL;
  document.getElementById('step2').classList.add('done');
}
function closePreview() { document.getElementById('prevOverlay').classList.remove('on'); }

// ── Add to Cart ──
function addToCart() {
  const objs=S.canvas.getObjects().filter(o=>!o.name||!o.name.startsWith('__'));
  if (!objs.length) { showToast('Please add artwork or text first!','warn'); return; }
  const token='DSN_'+Date.now().toString(36).toUpperCase();
  console.log('[POD] design_uuid:',token,'color:',S.colorName,'size:',S.size,'qty:',S.qty);
  window.postMessage({type:'pod_add_to_cart',design_uuid:token,variant_color:S.colorName,variant_size:S.size,qty:S.qty},'*');
  const cnt=document.getElementById('cartCount');
  cnt.textContent=parseInt(cnt.textContent||0)+S.qty;
  document.getElementById('step3').classList.add('done');
  showToast('Added to cart! ID: '+token,'success');
  setTimeout(()=>closeStudio(),2000);
}

// ── Footer Status ──
function updateFooter() {
  const objs=S.canvas.getObjects().filter(o=>!o.name||!o.name.startsWith('__'));
  const active=S.canvas.getActiveObject();
  let msg='Ready — add your design above';
  if (objs.length>0&&!active) msg=objs.length+' element(s) on canvas — click to select';
  if (active) msg='Selected: '+(active.type==='textbox'?'"'+active.text.substring(0,20)+'"':'Image');
  document.getElementById('footerStatus').textContent=msg;
}

// ── Toast ──
function showToast(msg, type) {
  const t=document.getElementById('toast');
  t.textContent=msg;
  t.className='toast'+(type?' '+type:'');
  t.classList.add('show');
  setTimeout(()=>t.classList.remove('show'),2800);
}
